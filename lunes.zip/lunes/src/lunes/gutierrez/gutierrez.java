/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lunes.gutierrez;

/**
 *
 * @author uan Sebastian Gutierrez Fuentes SebaGut2103
 */
public class gutierrez {
    double num;
    double num2;
    double suma;
    double resta;
    double multi;

    public gutierrez(double suma, double resta, double multi) {
        this.suma = suma;
        this.resta = resta;
        this.multi = multi;
    }
    public void sumaNum(){
        suma = num + num2;
    }
    public void restaNum(){
        resta = num - num2;
    }
    public void multiNum(){
        multi = num * num2;
    }
        
}
